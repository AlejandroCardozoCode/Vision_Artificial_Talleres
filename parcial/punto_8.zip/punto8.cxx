#include "opencv2/imgproc.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/highgui.hpp"
#include <iostream>

int main(int argc, char **argv)
{
    cv::Mat img1, img2;
    img1 = cv::imread(argv[1], 1);
    if (img1.empty())
    {
        std::cout << " ADVERTENCIA: error en la lectura de la imagen!" << std::endl;
        return -1;
    }
    cv::Mat matrix = (cv::Mat_<float>(3,3) << 0.62, -0.75, -21, 
                                            1.08, 0.43, 15, 
                                            0, 0, 1);
                                            
    warpPerspective( img1, img2, matrix, img2.size());
    imwrite("final_punto_8.jpg", img2);
}