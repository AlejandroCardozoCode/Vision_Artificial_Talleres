#include "opencv2/imgproc.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/highgui.hpp"
#include <iostream>

int main(int argc, char **argv)
{
    cv::Mat img1, img2, img3;
    cv::Point anchor;
    double delta;
    int ddepth;
    cv::Mat K1, K2;
    
    img1 = cv::imread(argv[1], 1);
    if (img1.empty())
    {
        std::cout << "Advertencia: no se pudo abrir la imagen" << std::endl;
        return -1;
    }

    anchor = cv::Point(-1, -1);
    delta = 0;
    ddepth = -1;
    K1 = (cv::Mat_<float>(3,3) << -(1/3), -(1/3), -(1/3), 1, 1, 1, -(1/3), -(1/3), -(1/3));
    K2 = (cv::Mat_<float>(3,3) << 1, 0, -21, 0, 1, 15, 0, 0, 1);

    filter2D(img1, img2, ddepth, K1, anchor, delta, cv::BORDER_DEFAULT);
    filter2D(img1, img3, ddepth, K2, anchor, delta, cv::BORDER_DEFAULT);
    imwrite("K1.jpg", img2);
    imwrite("K2.jpg", img3);
    return 0;
}